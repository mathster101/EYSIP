from django.shortcuts import render,HttpResponse
from home.models import Contacts
from datetime import datetime
# Create your views here.
def index(request):
    context = {
        "variable1" : "sent from views.py",
        "variable2" : "jeff"
    }
    return render(request,'index.html',context)

def about(request):
    if request.method == "POST":
        name = request.POST.get('name')
        contact = Contacts(name = name, date = datetime.today())
        contact.save()
    return render(request,'about.html')

def meme(request):
    return HttpResponse("my lyf meme")
